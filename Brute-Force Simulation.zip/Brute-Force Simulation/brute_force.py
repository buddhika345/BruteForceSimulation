import sys
import time

if len(sys.argv) != 3:
    print("Usage: python3 brute_force.py <email> <password>")
    sys.exit(1)

email = sys.argv[1]
password = sys.argv[2]

print("[*] Starting brute-force simulation...")
time.sleep(2)

# Simulate attack
print("[*] Cracking credentials...")
for i in range(5):
    print(f"[*] Attempt {i+1}...")
    time.sleep(1)

print(f"\n✅ User credentials cracked!")
print(f"Email: {email}")
print(f"Password: {password}")

# Keep terminal open
input("\nPress Enter to close the terminal...")


