from flask import Flask, request, render_template
import hashlib
import json
import os
import subprocess

app = Flask(__name__)
USER_FILE = "users.json"

def load_users():
    if not os.path.exists(USER_FILE):
        return {}
    with open(USER_FILE, "r") as f:
        return json.load(f)

def save_users(users):
    with open(USER_FILE, "w") as f:
        json.dump(users, f, indent=4)

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

@app.route("/", methods=["GET", "POST"])
def index():
    message = ""
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
        action = request.form["action"]

        users = load_users()

        if action == "signup":
            if email in users:
                message = "❌ User already exists."
            else:
                users[email] = hash_password(password)
                save_users(users)
                message = "✅ Sign up successful. You can now sign in."

        elif action == "signin":
            if email not in users:
                message = "❌ User not found. Please sign up first."
            elif users[email] != hash_password(password):
                message = "❌ Incorrect password."
            else:
                message = "✅ Login successful!"
                # Run brute_force.py with arguments in a new terminal
                subprocess.Popen(["gnome-terminal", "--", "python3", "brute_force.py", email, password])

    return render_template("index.html", message=message)

if __name__ == "__main__":
    app.run(debug=True,port=5000)

