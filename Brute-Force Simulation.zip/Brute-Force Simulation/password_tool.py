import tkinter as tk
from tkinter import messagebox
import hashlib
import itertools

# Simulated database
user_db = {}

# Load wordlist
with open("common_passwords.txt", "r") as f:
    common_passwords = [line.strip() for line in f.readlines()]

# Password hashing
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Dictionary attack
def dictionary_attack(target_hash, wordlist):
    for word in wordlist:
        if hash_password(word) == target_hash:
            return word
    return None

# Hybrid attack
def hybrid_attack(target_hash, wordlist, max_append=3):
    for word in wordlist:
        for num in range(10**max_append):
            guess = f"{word}{num}"
            if hash_password(guess) == target_hash:
                return guess
    return None

# Brute force attack
def brute_force_attack(target_hash, charset, max_length):
    for length in range(1, max_length + 1):
        for guess in itertools.product(charset, repeat=length):
            attempt = ''.join(guess)
            if hash_password(attempt) == target_hash:
                return attempt
    return None

# Terminal simulation prompt
def run_simulation(email):
    if email not in user_db:
        print("[!] User not found.")
        return

    hashed = user_db[email]
    print("\n[ Brute Force Simulation Started ]")
    print("Choose attack type:\n1. Dictionary\n2. Hybrid\n3. Brute Force")
    choice = input("Enter choice (1-3): ")

    if choice == "1":
        result = dictionary_attack(hashed, common_passwords)
    elif choice == "2":
        result = hybrid_attack(hashed, common_passwords)
    elif choice == "3":
        charset = "abc123"  # Limited charset for demo
        result = brute_force_attack(hashed, charset, max_length=4)
    else:
        print("Invalid option.")
        return

    if result:
        print(f"[✔] Password cracked: {result}")
    else:
        print("[✖] Failed to crack password.")

# GUI App
class AuthApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Auth Portal")
        self.geometry("400x250")
        self.create_widgets()

    def create_widgets(self):
        tk.Label(self, text="Email:").pack()
        self.email_entry = tk.Entry(self, width=40)
        self.email_entry.pack()

        tk.Label(self, text="Password:").pack()
        self.password_entry = tk.Entry(self, show="*", width=40)
        self.password_entry.pack()

        tk.Button(self, text="Signup", command=self.signup).pack(pady=5)
        tk.Button(self, text="Login & Simulate", command=self.login).pack(pady=5)

    def signup(self):
        email = self.email_entry.get()
        password = self.password_entry.get()
        if email in user_db:
            messagebox.showerror("Error", "User already exists.")
            return
        user_db[email] = hash_password(password)
        messagebox.showinfo("Success", "Signup successful!")

    def login(self):
        email = self.email_entry.get()
        password = self.password_entry.get()
        if email in user_db and user_db[email] == hash_password(password):
            messagebox.showinfo("Login", "Login successful! Run simulation in terminal.")
            run_simulation(email)
        else:
            messagebox.showerror("Error", "Invalid login.")

if __name__ == "__main__":
    app = AuthApp()
    app.mainloop()

